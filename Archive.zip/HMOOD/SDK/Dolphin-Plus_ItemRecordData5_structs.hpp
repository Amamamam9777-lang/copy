#pragma once

// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:43 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct ItemRecordData5.ItemRecordData5
// 0x0038
struct FItemRecordData5
{
	int                                                ItemID_2_2F9636FC420298B4EF34E588F58E38B0;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemType_4_B2ED20EE489C1F500EBA389884CAC16D;              // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ItemName_7_DEB27023488D6036B9B24AB5DB114F34;              // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ItemBigIcon_9_A4409DA14B47CD0F4D6A7EBB7CBF2F2F;           // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ItemDesc_11_8AB433674EC5E4AF7F82069136B23CF5;             // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

