#pragma once

// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:43 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_TransColumns_type.BP_STRUCT_TransColumns_type
// 0x0020
struct FBP_STRUCT_TransColumns_type
{
	struct FString                                     Columns_0_47AC24714CA709ABE62AB2B97B02C861;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Table_1_B0FEB2B8486D4078687135A2F1589ADF;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

