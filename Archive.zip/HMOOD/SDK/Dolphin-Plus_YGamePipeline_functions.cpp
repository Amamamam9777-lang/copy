// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:42 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function YGamePipeline.YGamePipelineHelper.SendDataWithKey
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 MsgKey                         (Parm, ZeroConstructor)
// TArray<unsigned char>          Data                           (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UYGamePipelineHelper::SendDataWithKey(const struct FString& MsgKey, TArray<unsigned char> Data)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.SendDataWithKey");

	UYGamePipelineHelper_SendDataWithKey_Params params;
	params.MsgKey = MsgKey;
	params.Data = Data;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function YGamePipeline.YGamePipelineHelper.SendData
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 MsgInfo                        (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UYGamePipelineHelper::SendData(const struct FString& MsgInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.SendData");

	UYGamePipelineHelper_SendData_Params params;
	params.MsgInfo = MsgInfo;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function YGamePipeline.YGamePipelineHelper.Release
// (Final, Native, Public, BlueprintCallable)

void UYGamePipelineHelper::Release()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.Release");

	UYGamePipelineHelper_Release_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function YGamePipeline.YGamePipelineHelper.RecvdDataWithKeyTest
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 MsgKey                         (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UYGamePipelineHelper::RecvdDataWithKeyTest(const struct FString& MsgKey)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.RecvdDataWithKeyTest");

	UYGamePipelineHelper_RecvdDataWithKeyTest_Params params;
	params.MsgKey = MsgKey;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function YGamePipeline.YGamePipelineHelper.RecvDataTest
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 MsgInfo                        (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UYGamePipelineHelper::RecvDataTest(const struct FString& MsgInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.RecvDataTest");

	UYGamePipelineHelper_RecvDataTest_Params params;
	params.MsgInfo = MsgInfo;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function YGamePipeline.YGamePipelineHelper.Log
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 LogInfo                        (Parm, ZeroConstructor)

void UYGamePipelineHelper::Log(const struct FString& LogInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.Log");

	UYGamePipelineHelper_Log_Params params;
	params.LogInfo = LogInfo;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function YGamePipeline.YGamePipelineHelper.IsConnected
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UYGamePipelineHelper::IsConnected()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.IsConnected");

	UYGamePipelineHelper_IsConnected_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function YGamePipeline.YGamePipelineHelper.Init
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UYGamePipelineHelper::Init()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.Init");

	UYGamePipelineHelper_Init_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function YGamePipeline.YGamePipelineHelper.Get
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// class UYGamePipelineHelper*    ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class UYGamePipelineHelper* UYGamePipelineHelper::Get()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function YGamePipeline.YGamePipelineHelper.Get");

	UYGamePipelineHelper_Get_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

