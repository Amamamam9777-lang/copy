#pragma once

// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:41 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class Basic.PlayerActorChannelExActor
// 0x0000 (0x04B0 - 0x04B0)
class APlayerActorChannelExActor : public AActor
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.PlayerActorChannelExActor");
		return pStaticClass;
	}

};


// Class Basic.PlayerReliableSequentialSyncActor
// 0x0010 (0x04C0 - 0x04B0)
class APlayerReliableSequentialSyncActor : public APlayerActorChannelExActor
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x04B0(0x0008) MISSED OFFSET
	class APlayerController*                           OwningController;                                         // 0x04B8(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.PlayerReliableSequentialSyncActor");
		return pStaticClass;
	}


	void OnActorSpawned(class AActor* Actor);
};


// Class Basic.UAENetActor
// 0x0010 (0x0580 - 0x0570)
class AUAENetActor : public ALuaActor
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0570(0x0008) MISSED OFFSET
	int                                                iRegionActor;                                             // 0x0578(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bStaticAddNetworkActor;                                   // 0x057C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      AutoDormancyType;                                         // 0x057D(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x057E(0x0002) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAENetActor");
		return pStaticClass;
	}


	void ReceivedPlayerActiveRegionsChanged(bool bEnter);
};


// Class Basic.OnlyActorComponent
// 0x0008 (0x0180 - 0x0178)
class UOnlyActorComponent : public UActorComponent
{
public:
	unsigned char                                      bCanEverUpdate;                                           // 0x0178(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0179(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.OnlyActorComponent");
		return pStaticClass;
	}

};


// Class Basic.UAEAnimListComponentBase
// 0x0150 (0x02C8 - 0x0178)
class UUAEAnimListComponentBase : public UActorComponent
{
public:
	unsigned char                                      UnknownData00[0xB0];                                      // 0x0178(0x00B0) MISSED OFFSET
	TMap<int, struct FAnimListMapValueData>            AnimListMap;                                              // 0x0228(0x0050) (ZeroConstructor, Transient)
	TArray<class UAnimationAsset*>                     AnimationCacheList;                                       // 0x0278(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x38];                                      // 0x0288(0x0038) MISSED OFFSET
	bool                                               bDisableAnimListOnDS;                                     // 0x02C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x02C1(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAEAnimListComponentBase");
		return pStaticClass;
	}

};


// Class Basic.ItemHandleBase
// 0x0080 (0x00A8 - 0x0028)
class UItemHandleBase : public UObject
{
public:
	int                                                Count;                                                    // 0x0028(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxCount;                                                 // 0x002C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUnique;                                                  // 0x0030(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bStackable;                                               // 0x0031(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bSingle;                                                  // 0x0032(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bDisableUse;                                              // 0x0033(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0034(0x0004) MISSED OFFSET
	TMap<int, struct FItemAssociation>                 AssociationMap;                                           // 0x0038(0x0050) (ZeroConstructor)
	struct FItemDefineID                               DefineID;                                                 // 0x0088(0x0018)
	unsigned char                                      UnknownData01[0x8];                                       // 0x00A0(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.ItemHandleBase");
		return pStaticClass;
	}


	void SetAssociation(int AssociationType, const struct FItemAssociation& Association);
	void RemoveAssociation(int AssociationType);
	void Init(const struct FItemDefineID& InDefineID);
	struct FItemDefineID GetDefineID();
	TMap<int, struct FItemAssociation> GetAssociationMap();
	TArray<struct FItemAssociation> GetAssociationListByTargetType(int Type);
	struct FItemAssociation GetAssociationByTargetDefineID(const struct FItemDefineID& TargetDefineID);
	struct FItemAssociation GetAssociation(int AssociationType);
	void Constuct(const struct FItemDefineID& InDefineID);
	void CollectionNeedLoadSoftPath(TArray<struct FSoftObjectPath>* OutSoftPathList);
	void AddAssociation(int AssociationType, const struct FItemAssociation& Association);
};


// Class Basic.BattleItemHandleBase
// 0x0090 (0x0138 - 0x00A8)
class UBattleItemHandleBase : public UItemHandleBase
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x00A8(0x0058) MISSED OFFSET
	struct FString                                     LuaFilePath;                                              // 0x0100(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bEquipping;                                               // 0x0110(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EItemStoreArea                                     ItemStoreArea;                                            // 0x0111(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0112(0x0006) MISSED OFFSET
	TArray<struct FBattleItemAdditionalData>           AdditionalData;                                           // 0x0118(0x0010) (BlueprintVisible, ZeroConstructor)
	bool                                               bDropOnDead;                                              // 0x0128(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	bool                                               bDropWhenDisuse;                                          // 0x0129(0x0001) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x012A(0x0002) MISSED OFFSET
	float                                              UnitWeight;                                               // 0x012C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEquippable;                                              // 0x0130(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bConsumable;                                              // 0x0131(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAutoEquipAndDrop;                                        // 0x0132(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x1];                                       // 0x0133(0x0001) MISSED OFFSET
	int                                                ItemAttrsFlag;                                            // 0x0134(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BattleItemHandleBase");
		return pStaticClass;
	}


	void UpdateAttributeModify(bool bEnable);
	bool UnEquip();
	bool ShouldDropInDisuse(const TScriptInterface<class UItemContainerInterface>& ItemContainer, const struct FItemDefineID& CurrentPickupItemDefineID, const struct FItemDefineID& ThisItemDefineID, int KeptCount, EBattleItemDisuseReason Reason);
	bool HanldePickupAssociationData(TArray<struct FBattleItemAdditionalData> PickupAdditionalData);
	bool HanldeDropAssociationData();
	bool HanldeCleared();
	bool HandleUse(const struct FBattleItemUseTarget& Target, EBattleItemUseReason Reason);
	bool HandlePickup(const TScriptInterface<class UItemContainerInterface>& ItemContainer, const struct FBattleItemPickupInfo& PickupInfo, EBattleItemPickupReason Reason);
	bool HandleEnable(bool bEnable);
	bool HandleDrop(int InCount, EBattleItemDropReason Reason);
	bool HandleDisuse(EBattleItemDisuseReason Reason);
	bool HandleChangeItemStoreArea(EItemStoreArea InItemStoreArea);
	bool HandleBindToTargetItem();
	class UWorld* GetWorldInternal();
	class UWorld* GetCurrentWorld();
	struct FBattleItemData ExtractItemData();
	void ClearAdditionalDataByType(EBattleItemAdditionalDataType DataType);
	void ClearAdditionalData();
	bool CheckCanUse(const TScriptInterface<class UItemContainerInterface>& ItemContainer, const struct FBattleItemUseTarget& Target, EBattleItemUseReason Reason);
};


// Class Basic.UAEGameInstance
// 0x0280 (0x0568 - 0x02E8)
class UUAEGameInstance : public UGameInstance
{
public:
	struct FClientBaseInfo                             ClientBaseInfo;                                           // 0x02E8(0x0158)
	struct FScriptMulticastDelegate                    EnginePreTick;                                            // 0x0440(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData00[0x68];                                      // 0x0450(0x0068) MISSED OFFSET
	class UFrontendHUD*                                AssociatedFrontendHUD;                                    // 0x04B8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x8];                                       // 0x04C0(0x0008) MISSED OFFSET
	class ULuaStateWrapper*                            LuaStateWrapper;                                          // 0x04C8(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bStandAloneFromLobby;                                     // 0x04D0(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x27];                                      // 0x04D1(0x0027) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnPreBattleResult;                                        // 0x04F8(0x0010) (BlueprintVisible, ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData03[0x10];                                      // 0x0508(0x0010) MISSED OFFSET
	TArray<struct FString>                             HighWeatherNames;                                         // 0x0518(0x0010) (ZeroConstructor, Config)
	int                                                HighWeatherMinRenderQuality;                              // 0x0528(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData)
	int                                                HighWeatherMaxRenderQuality;                              // 0x052C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData)
	int                                                ModeID;                                                   // 0x0530(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x0534(0x0004) MISSED OFFSET
	struct FString                                     ModType;                                                  // 0x0538(0x0010) (ZeroConstructor)
	struct FString                                     ModType2;                                                 // 0x0548(0x0010) (ZeroConstructor)
	TArray<struct FString>                             ExtraModules;                                             // 0x0558(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAEGameInstance");
		return pStaticClass;
	}


	void SetModeID(int InModeID);
	void SetLuaStateWrapper(class ULuaStateWrapper* TLuaStateWrapper);
	void SetExtraModules(TArray<struct FString> InExtraModules);
	void OpenAssetLoadLog();
	void OnPreBattleResult__DelegateSignature();
	void LuaLeakDetect();
	void LuaDoString(const struct FString& LuaString);
	float GetWeatherTime();
	struct FString GetWeatherLevelName();
	int GetWeatherID();
	struct FString GetModType2();
	struct FString GetModType();
	int GetModeID();
	class ULuaStateWrapper* GetLuaStateWrapper();
	struct FString GetLoadWeatherName(const struct FString& InWeatherName);
	bool GetIsHighWeatherLevel(const struct FString& InWeatherLevelName);
	struct FString GetGameID();
	struct FString GetExtraModulesString();
	TArray<struct FString> GetExtraModules();
	int GetDeviceLevel();
	class UUAEDataTable* GetDataTable_Mod(const struct FString& tableName);
	class UUAEDataTable* GetDataTable(const struct FString& tableName);
	class UFrontendHUD* GetAssociatedFrontendHUD();
	void CloseAssetLoadLog();
};


// Class Basic.UAENetBunchQueueSystem
// 0x0000 (0x0030 - 0x0030)
class UUAENetBunchQueueSystem : public UWorldSubsystem
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAENetBunchQueueSystem");
		return pStaticClass;
	}

};


// Class Basic.UAEBaseSkillCondition
// 0x0008 (0x0088 - 0x0080)
class UUAEBaseSkillCondition : public UUTSkillCondition
{
public:
	class APawn*                                       OwnerPawnForBuff;                                         // 0x0080(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAEBaseSkillCondition");
		return pStaticClass;
	}

};


// Class Basic.AttrModifyComponent
// 0x07E0 (0x0958 - 0x0178)
class UAttrModifyComponent : public UActorComponent
{
public:
	unsigned char                                      UnknownData00[0xF0];                                      // 0x0178(0x00F0) MISSED OFFSET
	int                                                ConfigAutoAddAttId;                                       // 0x0268(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0xA4];                                      // 0x026C(0x00A4) MISSED OFFSET
	TArray<struct FAttrModifyItem>                     ConfigAttrModifyList;                                     // 0x0310(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData02[0xA0];                                      // 0x0320(0x00A0) MISSED OFFSET
	uint32_t                                           AttrModifyStateList;                                      // 0x03C0(0x0004) (Net, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData03[0x74];                                      // 0x03C4(0x0074) MISSED OFFSET
	struct FRepAttributeModify                         DynamicModifierRep;                                       // 0x0438(0x0018) (Net)
	struct FRepAttributeModify                         DynamicModifierRepOnlyOwner;                              // 0x0450(0x0018) (Net)
	unsigned char                                      UnknownData04[0x20];                                      // 0x0468(0x0020) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnAttrModified;                                           // 0x0488(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnAttrRemoved;                                            // 0x0498(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FAttrDynamicModifier                        DynamicModifier;                                          // 0x04A8(0x00A8)
	unsigned char                                      UnknownData05[0x50];                                      // 0x0550(0x0050) MISSED OFFSET
	TArray<struct FAttributeExpand>                    AttributeExpands;                                         // 0x05A0(0x0010) (Edit, ZeroConstructor)
	bool                                               bAddReserveNum;                                           // 0x05B0(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData06[0x7];                                       // 0x05B1(0x0007) MISSED OFFSET
	TMap<struct FString, struct FRelateAttributeGroup> RelateAttributeGroup;                                     // 0x05B8(0x0050) (ZeroConstructor)
	EActorRegAttrTableType                             ActorAttrType;                                            // 0x0608(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData07[0x10F];                                     // 0x0609(0x010F) MISSED OFFSET
	TArray<struct FModAttrSimulateSyncItem>            ModSimulateSyncList;                                      // 0x0718(0x0010) (Net, ZeroConstructor)
	unsigned char                                      UnknownData08[0x108];                                     // 0x0728(0x0108) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnNeedSetSpeedOverLimit;                                  // 0x0830(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData09[0xF8];                                      // 0x0840(0x00F8) MISSED OFFSET
	TArray<struct FAttrModifyRecordItem>               ExceptionAttrModifyRecords_DS;                            // 0x0938(0x0010) (BlueprintVisible, Net, ZeroConstructor)
	TArray<struct FAttrModifyRecordItem>               ExceptionAttrModifyRecords_Client;                        // 0x0948(0x0010) (BlueprintVisible, Net, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.AttrModifyComponent");
		return pStaticClass;
	}


	bool SwitchAttrModifierByIndex(int ModifyConfigIndex, bool Enable);
	bool SwitchAttrModifier(const struct FString& AttrModifyItemName, bool Enable);
	void StartTimerToSyncRecordAttrValue(float Time);
	void SetValueToAttributeSafety(const struct FString& AttrName, float Value, int ModifyRecordType);
	void SetOrignalValueToAttribute(const struct FString& AttrName, float Value);
	void SetOrignalValueAndBaseValue(const struct FString& AttrName, float Value);
	void SetAttrModifyStateValue(int Index, bool Value);
	void SetAttributeMinValue(const struct FString& AttrName, float MinValue);
	void SetAttributeMaxValue(const struct FString& AttrName, float MaxValue);
	void ServerSendExceptionType(const struct FString& AttrName, int ExceptionType);
	void ServerRequestRecordAttrValue(const struct FString& AttrName);
	void ResponeAttrValue(const struct FString& AttrName, float FinalValue);
	void RequestAttrValue(const struct FString& AttrName);
	bool RemoveModifyItemFromCache(uint32_t ModifyUID);
	void RemoveAttrListener(const struct FString& AttrName, const struct FSluaBPVar& Listener);
	void RemoveAllDynamicModifier(bool bForce);
	bool RegisterModifyAbleAttr(bool bSetAttrByOrigin, TArray<struct FAttrRegisterItem>* AttrRegists);
	void RegistAttrModifyRecordList(const struct FString& AttrName, int RecordLen);
	void RegCurrentModAttrs();
	void RefreshAttributeModify(const struct FString& AttrName);
	void PushAttrModifyRecordItem(const struct FString& AttrName, float PreValue, float CurValue, int ModifyRecordType, const struct FString& ModifyDesc);
	void OnRep_ModSimulateSyncList();
	void OnRep_ExceptionAttrModifyRecords();
	void OnRep_DynamicModifier();
	void OnRep_AttrModifyStateList();
	void OnNeedSetSpeedOverLimit__DelegateSignature();
	void OnAttrModifiedEvent__DelegateSignature(TArray<struct FAttrAffected> AffectedAttrS);
	void LuaSetValueToAttributeSafety(const struct FString& AttrName, float Value);
	bool IsAttrModifyStateValidIndex(int Index);
	void InitializeRelateAttributeExpands();
	bool HasDynamicModifier(const struct FString& AttrModifyId);
	void HandleExceptionAttrModify(const struct FString& AttrName, int ExceptionType);
	class UAttrModifyModDataSubsystem* GetSubsystem();
	struct FString GetMaxAttrName(const struct FString& AttrName);
	bool GetAttrModifyStateValue(int Index);
	int GetAttrModifyStateNum();
	struct FAttrModifyItem GetAttrModifyItemByItemName(const struct FString& ItemName);
	float GetAttributeValue(const struct FString& AttrName);
	float GetAttributeOrignalValue(const struct FString& AttrName);
	float GetAttributeMaxValue(const struct FString& AttrName);
	struct FString GetAttrDynamicModifyTargetString(const struct FAttrDynamicModifyTarget& DynamicModifyTarget);
	struct FString GetAttrDynamicModifyItemString(const struct FAttrDynamicModifyItem& DynamicModifyItem);
	bool EnableAttrModifierByIndex(int ModifyConfigIndex);
	bool EnableAttrModifier(const struct FString& AttrModifyItemName);
	bool DisableAttrModifierByIndex(int ModifyConfigIndex);
	bool DisableAttrModifier(const struct FString& AttrModifyItemName);
	bool DisableAllAttrModifier(bool bForce);
	void ConditionSyncRecordAttrValue();
	void ClientSyncRecordAttrValue(TArray<struct FAttrDesc> AttrDescs);
	void ClientSendRecordData(const struct FAttrModifyRecordItem& RecordItem, int ExceptionType);
	void ClearAllAttrModify();
	void AddValueToAttribute(const struct FString& AttrName, float Value);
	uint32_t AddModifyItemAndCache(const struct FString& AttrName, EAttrModifyRefType CModifyType, float CValue, bool bEnable, class UObject* Causer, bool bOldModify);
	void AddDynamicModifier(bool RepOnlyOwner, struct FAttrModifyItem* AttrModifyItem);
	uint32_t AddBModifyAndCacheWithCParam(const struct FString& AttrName, EAttrModifyRefType CModifyType, float CValue, bool ClientSimulate);
	uint32_t AddBModifyAndCache(const struct FString& AttrName, EAttrOperator ModifyType, float Value, bool ClientSimulate);
	void AddAttrListener(const struct FString& AttrName, const struct FSluaBPVar& Listener);
};


// Class Basic.AttrModifyInterface
// 0x0000 (0x0028 - 0x0028)
class UAttrModifyInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.AttrModifyInterface");
		return pStaticClass;
	}


	void SetAttrValue(const struct FString& AttrName, float NewVal, int Reason);
	void RequestAttrValue(const struct FString& AttrName);
	void RegisterModifiedAttributes();
	float GetAttrValue(const struct FString& AttrName);
	TArray<class AActor*> GetAttrModifyRelevantActors();
	class UAttrModifyComponent* GetAttrModifyComponent();
	float GetAttributeValue(const struct FString& AttrName);
	void AddAttrValue(const struct FString& AttrName, float AddVal, int Reason);
};


// Class Basic.AttrModifyModDataSubsystem
// 0x0158 (0x0188 - 0x0030)
class UAttrModifyModDataSubsystem : public UWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x158];                                     // 0x0030(0x0158) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.AttrModifyModDataSubsystem");
		return pStaticClass;
	}

};


// Class Basic.BCDataTable
// 0x0088 (0x00B0 - 0x0028)
class UBCDataTable : public UObject
{
public:
	class UScriptStruct*                               BigRowStruct;                                             // 0x0028(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x68];                                      // 0x0030(0x0068) MISSED OFFSET
	class UUAEDataTable*                               FixedTable;                                               // 0x0098(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x10];                                      // 0x00A0(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BCDataTable");
		return pStaticClass;
	}

};


// Class Basic.BlueprintFunctionOverride
// 0x0068 (0x0090 - 0x0028)
class UBlueprintFunctionOverride : public UBlueprintFunctionLibrary
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0028(0x0058) MISSED OFFSET
	struct FString                                     LuaFilePath;                                              // 0x0080(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BlueprintFunctionOverride");
		return pStaticClass;
	}

};


// Class Basic.LuaDataAsset
// 0x0068 (0x0098 - 0x0030)
class ULuaDataAsset : public UDataAsset
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0030(0x0058) MISSED OFFSET
	struct FString                                     LuaFilePath;                                              // 0x0088(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.LuaDataAsset");
		return pStaticClass;
	}

};


// Class Basic.BPClassManager
// 0x0160 (0x01F8 - 0x0098)
class UBPClassManager : public ULuaDataAsset
{
public:
	TArray<struct FBPClassItem>                        BPClassList;                                              // 0x0098(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData00[0x50];                                      // 0x00A8(0x0050) UNKNOWN PROPERTY: MapProperty Basic.BPClassManager.BPClassLookUp
	TMap<class UClass*, struct FBPClassItemMap>        BPClassLookUpOverride;                                    // 0x00F8(0x0050) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x50];                                      // 0x0148(0x0050) UNKNOWN PROPERTY: MapProperty Basic.BPClassManager.BPClassNameLookUp
	TMap<struct FString, struct FBPClassItemMap>       BPClassNameLookUpOverride;                                // 0x0198(0x0050) (ZeroConstructor, Transient)
	struct FString                                     BPClassManagerPath;                                       // 0x01E8(0x0010) (ZeroConstructor, Config)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BPClassManager");
		return pStaticClass;
	}


	void ModifyClass(class UClass* InNativeClass, const struct FString& BPClassPath, const struct FString& ModTag);
	class UClass* GetUClass(int KeyIndex);
	class UClass* GetBPClassOverrideByName(const struct FString& ClassTagName, const struct FString& ModTag);
	class UClass* GetBPClassOverride(class UClass* InNativeClass, const struct FString& ModTag);
	static class UBPClassManager* Get();
};


// Class Basic.BudgetSchedulerSettings
// 0x0010 (0x0048 - 0x0038)
class UBudgetSchedulerSettings : public UDeveloperSettings
{
public:
	TArray<struct FBudgetSchedulerChannelConfig>       Channels;                                                 // 0x0038(0x0010) (Edit, ZeroConstructor, Config)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BudgetSchedulerSettings");
		return pStaticClass;
	}

};


// Class Basic.BuffConfigSubsystem
// 0x0180 (0x01B0 - 0x0030)
class UBuffConfigSubsystem : public UBattleSubsystem
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0030(0x0020) MISSED OFFSET
	TMap<struct FString, class UClass*>                BuffClassMap;                                             // 0x0050(0x0050) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x110];                                     // 0x00A0(0x0110) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BuffConfigSubsystem");
		return pStaticClass;
	}


	void ReloadTable(class UWorld* World);
	void ClearTable();
};


// Class Basic.BuffNodeLuaInterface
// 0x0000 (0x0028 - 0x0028)
class UBuffNodeLuaInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BuffNodeLuaInterface");
		return pStaticClass;
	}

};


// Class Basic.BuffUtils
// 0x0000 (0x0028 - 0x0028)
class UBuffUtils : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BuffUtils");
		return pStaticClass;
	}


	static bool IsRoleOK(EBuffEnabledRole EnabledRole, class UActorComponent* OwnerComponent);
};


// Class Basic.CommonMessageDataLibrary
// 0x0000 (0x0028 - 0x0028)
class UCommonMessageDataLibrary : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.CommonMessageDataLibrary");
		return pStaticClass;
	}


	static void SetVectorArray(unsigned char Index, TArray<struct FVector> Values, struct FCommonMessageData* Target);
	static void SetVector4Array(unsigned char Index, TArray<struct FVector4> Values, struct FCommonMessageData* Target);
	static void SetVector4(unsigned char Index, const struct FVector4& Value, struct FCommonMessageData* Target);
	static void SetVector2DArray(unsigned char Index, TArray<struct FVector2D> Values, struct FCommonMessageData* Target);
	static void SetVector2D(unsigned char Index, const struct FVector2D& Value, struct FCommonMessageData* Target);
	static void SetVector(unsigned char Index, const struct FVector& Value, struct FCommonMessageData* Target);
	static void SetTransformArray(unsigned char Index, TArray<struct FTransform> Values, struct FCommonMessageData* Target);
	static void SetTransform(unsigned char Index, const struct FTransform& Value, struct FCommonMessageData* Target);
	static void SetStringArray(unsigned char Index, TArray<struct FString> Values, struct FCommonMessageData* Target);
	static void SetString(unsigned char Index, const struct FString& Value, struct FCommonMessageData* Target);
	static void SetRotatorArray(unsigned char Index, TArray<struct FRotator> Values, struct FCommonMessageData* Target);
	static void SetRotator(unsigned char Index, const struct FRotator& Value, struct FCommonMessageData* Target);
	static void SetQuatArray(unsigned char Index, TArray<struct FQuat> Values, struct FCommonMessageData* Target);
	static void SetQuat(unsigned char Index, const struct FQuat& Value, struct FCommonMessageData* Target);
	static void SetObjectArray(unsigned char Index, TArray<class UObject*> Values, struct FCommonMessageData* Target);
	static void SetObject(unsigned char Index, class UObject* Value, struct FCommonMessageData* Target);
	static void SetNameArray(unsigned char Index, TArray<struct FName> Values, struct FCommonMessageData* Target);
	static void SetName(unsigned char Index, const struct FName& Value, struct FCommonMessageData* Target);
	static void SetLinearColorArray(unsigned char Index, TArray<struct FLinearColor> Values, struct FCommonMessageData* Target);
	static void SetLinearColor(unsigned char Index, const struct FLinearColor& Value, struct FCommonMessageData* Target);
	static void SetIntVectorArray(unsigned char Index, TArray<struct FIntVector> Values, struct FCommonMessageData* Target);
	static void SetIntVector(unsigned char Index, const struct FIntVector& Value, struct FCommonMessageData* Target);
	static void SetIntPointArray(unsigned char Index, TArray<struct FIntPoint> Values, struct FCommonMessageData* Target);
	static void SetIntPoint(unsigned char Index, const struct FIntPoint& Value, struct FCommonMessageData* Target);
	static void SetInt64Array(unsigned char Index, TArray<int64_t> Values, struct FCommonMessageData* Target);
	static void SetInt64(unsigned char Index, int64_t Value, struct FCommonMessageData* Target);
	static void SetInt32Array(unsigned char Index, TArray<int> Values, struct FCommonMessageData* Target);
	static void SetInt32(unsigned char Index, int Value, struct FCommonMessageData* Target);
	static void SetFloatArray(unsigned char Index, TArray<float> Values, struct FCommonMessageData* Target);
	static void SetFloat(unsigned char Index, float Value, struct FCommonMessageData* Target);
	static void SetColorArray(unsigned char Index, TArray<struct FColor> Values, struct FCommonMessageData* Target);
	static void SetColor(unsigned char Index, const struct FColor& Value, struct FCommonMessageData* Target);
	static void SetClassArray(unsigned char Index, TArray<class UClass*> Values, struct FCommonMessageData* Target);
	static void SetClass(unsigned char Index, class UClass* Value, struct FCommonMessageData* Target);
	static void SetByteArray(unsigned char Index, TArray<unsigned char> Values, struct FCommonMessageData* Target);
	static void SetByte(unsigned char Index, unsigned char Value, struct FCommonMessageData* Target);
	static void SetBoolArray(unsigned char Index, TArray<bool> Values, struct FCommonMessageData* Target);
	static void SetBool(unsigned char Index, bool Value, struct FCommonMessageData* Target);
	static void SetActorArray(unsigned char Index, TArray<class AActor*> Values, struct FCommonMessageData* Target);
	static void SetActor(unsigned char Index, class AActor* Value, struct FCommonMessageData* Target);
	static bool Remove(unsigned char Index, struct FCommonMessageData* Target);
	static bool GetVectorArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FVector>* OutValues);
	static bool GetVector4Array(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FVector4>* OutValues);
	static bool GetVector4(const struct FCommonMessageData& Target, unsigned char Index, struct FVector4* OutValue);
	static bool GetVector2DArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FVector2D>* OutValues);
	static bool GetVector2D(const struct FCommonMessageData& Target, unsigned char Index, struct FVector2D* OutValue);
	static bool GetVector(const struct FCommonMessageData& Target, unsigned char Index, struct FVector* OutValue);
	static bool GetTransformArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FTransform>* OutValues);
	static bool GetTransform(const struct FCommonMessageData& Target, unsigned char Index, struct FTransform* OutValue);
	static bool GetStringArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FString>* OutValues);
	static bool GetString(const struct FCommonMessageData& Target, unsigned char Index, struct FString* OutValue);
	static bool GetRotatorArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FRotator>* OutValues);
	static bool GetRotator(const struct FCommonMessageData& Target, unsigned char Index, struct FRotator* OutValue);
	static bool GetQuatArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FQuat>* OutValues);
	static bool GetQuat(const struct FCommonMessageData& Target, unsigned char Index, struct FQuat* OutValue);
	static bool GetObjectArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<class UObject*>* OutValues);
	static bool GetObject(const struct FCommonMessageData& Target, unsigned char Index, class UObject** OutValue);
	static bool GetNameArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FName>* OutValues);
	static bool GetName(const struct FCommonMessageData& Target, unsigned char Index, struct FName* OutValue);
	static bool GetLinearColorArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FLinearColor>* OutValues);
	static bool GetLinearColor(const struct FCommonMessageData& Target, unsigned char Index, struct FLinearColor* OutValue);
	static bool GetIntVectorArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FIntVector>* OutValues);
	static bool GetIntVector(const struct FCommonMessageData& Target, unsigned char Index, struct FIntVector* OutValue);
	static bool GetIntPointArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FIntPoint>* OutValues);
	static bool GetIntPoint(const struct FCommonMessageData& Target, unsigned char Index, struct FIntPoint* OutValue);
	static bool GetInt64Array(const struct FCommonMessageData& Target, unsigned char Index, TArray<int64_t>* OutValues);
	static bool GetInt64(const struct FCommonMessageData& Target, unsigned char Index, int64_t* OutValue);
	static bool GetInt32Array(const struct FCommonMessageData& Target, unsigned char Index, TArray<int>* OutValues);
	static bool GetInt32(const struct FCommonMessageData& Target, unsigned char Index, int* OutValue);
	static bool GetFloatArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<float>* OutValues);
	static bool GetFloat(const struct FCommonMessageData& Target, unsigned char Index, float* OutValue);
	static struct FCommonMessageData GetEmptyCommonMessageData();
	static bool GetColorArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<struct FColor>* OutValues);
	static bool GetColor(const struct FCommonMessageData& Target, unsigned char Index, struct FColor* OutValue);
	static bool GetClassArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<class UClass*>* OutValues);
	static bool GetClass(const struct FCommonMessageData& Target, unsigned char Index, class UClass** OutValue);
	static bool GetByteArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<unsigned char>* OutValues);
	static bool GetByte(const struct FCommonMessageData& Target, unsigned char Index, unsigned char* OutValue);
	static bool GetBoolArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<bool>* OutValues);
	static bool GetBool(const struct FCommonMessageData& Target, unsigned char Index, bool* OutValue);
	static bool GetActorArray(const struct FCommonMessageData& Target, unsigned char Index, TArray<class AActor*>* OutValues);
	static bool GetActor(const struct FCommonMessageData& Target, unsigned char Index, class AActor** OutValue);
	static void Clear(struct FCommonMessageData* Target);
};


// Class Basic.DelayReplicationInterface
// 0x0000 (0x0028 - 0x0028)
class UDelayReplicationInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.DelayReplicationInterface");
		return pStaticClass;
	}


	void ReSendRPCAfterBeginPlay();
	void ReCallRepAfterBeginPlay();
};


// Class Basic.EnvLuaVM
// 0x0058 (0x0080 - 0x0028)
class UEnvLuaVM : public UObject
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0028(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.EnvLuaVM");
		return pStaticClass;
	}

};


// Class Basic.EnvLuaVMFactory
// 0x0000 (0x0028 - 0x0028)
class UEnvLuaVMFactory : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.EnvLuaVMFactory");
		return pStaticClass;
	}


	static class UEnvLuaVM* CreateEnvLuaVM(const struct FString& InLuaFilePath, class UObject* WorldContextObject);
};


// Class Basic.PathCompressionRef
// 0x0048 (0x0078 - 0x0030)
class UPathCompressionRef : public UDataAsset
{
public:
	TArray<struct FName>                               NodeNames;                                                // 0x0030(0x0010) (ZeroConstructor)
	TArray<uint32_t>                                   ParentIndices;                                            // 0x0040(0x0010) (ZeroConstructor)
	struct FString                                     Dict;                                                     // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FSoftObjectPath                             DataTableRef;                                             // 0x0060(0x0018) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.PathCompressionRef");
		return pStaticClass;
	}

};


// Class Basic.GameModeEnvInterface
// 0x0000 (0x0028 - 0x0028)
class UGameModeEnvInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.GameModeEnvInterface");
		return pStaticClass;
	}

};


// Class Basic.GameModeEnvUtil
// 0x0000 (0x0028 - 0x0028)
class UGameModeEnvUtil : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.GameModeEnvUtil");
		return pStaticClass;
	}


	static int GetModeID(const struct FString& GameModeClassPath);
	static bool GetGameModeEnvData(int InModeID, struct FGameModeEnvData* OutData);
};


// Class Basic.StackModifyAttrInterface
// 0x0000 (0x0028 - 0x0028)
class UStackModifyAttrInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.StackModifyAttrInterface");
		return pStaticClass;
	}


	void PushVectorModify(int ModifyKey, const struct FName& PropertyName, const struct FVector& InValue);
	void PushVector4Modify(int ModifyKey, const struct FName& PropertyName, const struct FVector4& InValue);
	void PushVector2DModify(int ModifyKey, const struct FName& PropertyName, const struct FVector2D& InValue);
	void PushTransformModify(int ModifyKey, const struct FName& PropertyName, const struct FTransform& InValue);
	void PushStringModify(int ModifyKey, const struct FName& PropertyName, const struct FString& InValue);
	void PushRotatorModify(int ModifyKey, const struct FName& PropertyName, const struct FRotator& InValue);
	void PushQuatModify(int ModifyKey, const struct FName& PropertyName, const struct FQuat& InValue);
	void PushNameModify(int ModifyKey, const struct FName& PropertyName, const struct FName& InValue);
	void PushLinearColorModify(int ModifyKey, const struct FName& PropertyName, const struct FLinearColor& InValue);
	void PushIntVectorModify(int ModifyKey, const struct FName& PropertyName, const struct FIntVector& InValue);
	void PushIntPointModify(int ModifyKey, const struct FName& PropertyName, const struct FIntPoint& InValue);
	void PushInt32Modify(int ModifyKey, const struct FName& PropertyName, int InValue);
	void PushFloatModify(int ModifyKey, const struct FName& PropertyName, float InValue);
	void PushColorModify(int ModifyKey, const struct FName& PropertyName, const struct FColor& InValue);
	void PushByteModify(int ModifyKey, const struct FName& PropertyName, unsigned char InValue);
	void PushBoolModify(int ModifyKey, const struct FName& PropertyName, bool InValue);
	bool PopStackModifyAttr(int ModifyKey, const struct FName& PropertyName);
	bool HasStackModify(const struct FName& PropertyName);
	struct FVector4 GetModifiedVector4(const struct FName& PropertyName, const struct FVector4& OriginalValue);
	struct FVector2D GetModifiedVector2D(const struct FName& PropertyName, const struct FVector2D& OriginalValue);
	struct FVector GetModifiedVector(const struct FName& PropertyName, const struct FVector& OriginalValue);
	struct FTransform GetModifiedTransform(const struct FName& PropertyName, const struct FTransform& OriginalValue);
	struct FString GetModifiedString(const struct FName& PropertyName, const struct FString& OriginalValue);
	struct FRotator GetModifiedRotator(const struct FName& PropertyName, const struct FRotator& OriginalValue);
	struct FQuat GetModifiedQuat(const struct FName& PropertyName, const struct FQuat& OriginalValue);
	struct FName GetModifiedName(const struct FName& PropertyName, const struct FName& OriginalValue);
	struct FLinearColor GetModifiedLinearColor(const struct FName& PropertyName, const struct FLinearColor& OriginalValue);
	struct FIntVector GetModifiedIntVector(const struct FName& PropertyName, const struct FIntVector& OriginalValue);
	struct FIntPoint GetModifiedIntPoint(const struct FName& PropertyName, const struct FIntPoint& OriginalValue);
	int GetModifiedInt32(const struct FName& PropertyName, int OriginalValue);
	float GetModifiedFloat(const struct FName& PropertyName, float OriginalValue);
	struct FColor GetModifiedColor(const struct FName& PropertyName, const struct FColor& OriginalValue);
	unsigned char GetModifiedByte(const struct FName& PropertyName, unsigned char OriginalValue);
	bool GetModifiedBool(const struct FName& PropertyName, bool OriginalValue);
};


// Class Basic.ItemContainerInterface
// 0x0000 (0x0028 - 0x0028)
class UItemContainerInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.ItemContainerInterface");
		return pStaticClass;
	}


	class UObject* GetOwningObject();
	TArray<class UItemHandleBase*> GetItemHandleListByDefineID(const struct FItemDefineID& DefineID);
	class UItemHandleBase* GetItemHandleByDefineID(const struct FItemDefineID& DefineID);
	TArray<struct FItemDefineID> GetItemDefineIDList();
	struct FItemDefineID GetFirstItemDefineBySpecificID(int ID);
};


// Class Basic.ItemContainerOwnerInterface
// 0x0000 (0x0028 - 0x0028)
class UItemContainerOwnerInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.ItemContainerOwnerInterface");
		return pStaticClass;
	}


	void NotifyUpdateCustomAccessoriesData(int WeaponItemId, int Index, int ItemId, bool bIsSetOrRemove);
	void NotifyUpdateCapacity(float InBackPackCapacity, float InOccupiedCapacity, float InSafetyBoxCapacity, float InSafetyBoxOccupiedCapacity);
	void NotifyItemUpdated(const struct FItemDefineID& DefineID, const struct FBattleItemData& ItemData);
	void NotifyItemRemoved(const struct FItemDefineID& DefineID, const struct FBattleItemData& ItemData);
	void NotifyItemEmpty();
	void NotifyItemAdded(const struct FItemDefineID& DefineID, const struct FBattleItemData& ItemData);
};


// Class Basic.ItemFactoryInterface
// 0x0000 (0x0028 - 0x0028)
class UItemFactoryInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.ItemFactoryInterface");
		return pStaticClass;
	}

};


// Class Basic.LuaAsyncTasksSubsystem
// 0x0008 (0x0038 - 0x0030)
class ULuaAsyncTasksSubsystem : public UGameInstanceSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.LuaAsyncTasksSubsystem");
		return pStaticClass;
	}


	bool IsNeedClear(float ClearMemorySize, float ClearArrayObjectSize, const struct FSluaBPVar& Callback);
};


// Class Basic.LuaAsyncTaskSubsystem
// 0x0008 (0x0038 - 0x0030)
class ULuaAsyncTaskSubsystem : public UGameInstanceSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.LuaAsyncTaskSubsystem");
		return pStaticClass;
	}


	bool IsNeedClear(class UFrontendHUD* FrontendHUD, const struct FSluaBPVar& Callback);
};


// Class Basic.LuaEventBridgeFunction
// 0x0000 (0x0028 - 0x0028)
class ULuaEventBridgeFunction : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.LuaEventBridgeFunction");
		return pStaticClass;
	}


	static void UnRegisterEventByTarget(class UObject* ObjContext);
	static void UnRegisterEvent(const struct FString& FEventType, const struct FString& EventID, class UObject* ObjContext, int EventHandle);
	static int RegistEvent(const struct FString& EventType, const struct FString& EventID, class UObject* ObjContext, const struct FString& FunctionName);
};


// Class Basic.LuaEventBridge
// 0x0130 (0x0158 - 0x0028)
class ULuaEventBridge : public UObject
{
public:
	TWeakObjectPtr<class ULuaStateWrapper>             LuaStateWrapper;                                          // 0x0028(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	TMap<struct FString, struct FEventTypeContainer>   RegisterEventMap;                                         // 0x0038(0x0050) (ZeroConstructor)
	TMap<struct FString, struct FLuaEventTypeContainer> LuaRegisterEventMap;                                      // 0x0088(0x0050) (ZeroConstructor)
	TMap<uint32_t, struct FLuaEventTypeToIDSet>        FilterKeyRegisterMap;                                     // 0x00D8(0x0050) (ZeroConstructor)
	TArray<class ULuaTemBPData*>                       CurrentParamArray;                                        // 0x0128(0x0010) (ZeroConstructor)
	TArray<class UProperty*>                           Params;                                                   // 0x0138(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x10];                                      // 0x0148(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.LuaEventBridge");
		return pStaticClass;
	}


	void SyncLuaRegisterEventNum(const struct FString& EventType, const struct FString& EventID, int Number);
	TArray<class ULuaTemBPData*> GetCurrentParam();
	void DeactivateEventsByFilterKey(uint32_t FilterKey);
	bool CheckNeedPostEventWithFilterKey(uint32_t FilterKey, const struct FString& EventType, const struct FString& EventID, bool bCheckNeedPostLua);
	void ActiveEventByFilterKey(uint32_t FilterKey, const struct FString& EventType, const struct FString& EventID, bool bActive);
};


// Class Basic.LuaEventSubsystem
// 0x0140 (0x0170 - 0x0030)
class ULuaEventSubsystem : public UGameInstanceSubsystem
{
public:
	unsigned char                                      UnknownData00[0x80];                                      // 0x0030(0x0080) MISSED OFFSET
	TArray<class ULuaTemBPData*>                       CurrentParamArray;                                        // 0x00B0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0xA0];                                      // 0x00C0(0x00A0) MISSED OFFSET
	struct FName                                       LastEventTriggerObjectName;                               // 0x0160(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       LastEventTriggerFunctionName;                             // 0x0168(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.LuaEventSubsystem");
		return pStaticClass;
	}


	void UnRegistEvent(int EventHandle);
	void SetBridgeFunction(const struct FSluaBPVar& OnRegistEvent, const struct FSluaBPVar& OnUnRegistEvent, const struct FSluaBPVar& OnPostEvent, const struct FSluaBPVar& OnPostBlueprintEvent);
	int RegistEvent(const struct FString& EventID, const struct FString& EventType, class UObject* Object, const struct FString& FunctionName);
};


// Class Basic.ModTable
// 0x00F8 (0x0120 - 0x0028)
class UModTable : public UObject
{
public:
	unsigned char                                      UnknownData00[0xF8];                                      // 0x0028(0x00F8) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.ModTable");
		return pStaticClass;
	}

};


// Class Basic.NetRelevancyGroup
// 0x0038 (0x0060 - 0x0028)
class UNetRelevancyGroup : public UObject
{
public:
	struct FNetRelevancyGroupID                        GroupID;                                                  // 0x0028(0x0004)
	unsigned char                                      UnknownData00[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	TArray<class UUAENetConnection*>                   Connections;                                              // 0x0030(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x20];                                      // 0x0040(0x0020) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.NetRelevancyGroup");
		return pStaticClass;
	}

};


// Class Basic.OnlyActorCompManagerComponent
// 0x0060 (0x01D8 - 0x0178)
class UOnlyActorCompManagerComponent : public UActorComponent
{
public:
	TMap<struct FString, class UOnlyActorComponent*>   CacheComponents;                                          // 0x0178(0x0050) (ExportObject, ZeroConstructor)
	TArray<class UOnlyActorComponent*>                 CacheUpdateComponents;                                    // 0x01C8(0x0010) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.OnlyActorCompManagerComponent");
		return pStaticClass;
	}

};


// Class Basic.OnlyActorComponentManagerInterface
// 0x0000 (0x0028 - 0x0028)
class UOnlyActorComponentManagerInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.OnlyActorComponentManagerInterface");
		return pStaticClass;
	}

};


// Class Basic.OwnerRelevancyDependencyInterface
// 0x0000 (0x0028 - 0x0028)
class UOwnerRelevancyDependencyInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.OwnerRelevancyDependencyInterface");
		return pStaticClass;
	}

};


// Class Basic.PlayerActorChannelEx
// 0x0000 (0x0580 - 0x0580)
class UPlayerActorChannelEx : public UActorChannel
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.PlayerActorChannelEx");
		return pStaticClass;
	}

};


// Class Basic.PlayerReliableSequentialSyncActorChannel
// 0x0000 (0x0580 - 0x0580)
class UPlayerReliableSequentialSyncActorChannel : public UPlayerActorChannelEx
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.PlayerReliableSequentialSyncActorChannel");
		return pStaticClass;
	}

};


// Class Basic.RenderFunctionLibrary
// 0x0000 (0x0028 - 0x0028)
class URenderFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.RenderFunctionLibrary");
		return pStaticClass;
	}


	static void MarkComponentRenderStateDirty(class UActorComponent* Comp);
};


// Class Basic.RepPropertyModOptim
// 0x0060 (0x0088 - 0x0028)
class URepPropertyModOptim : public UObject
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x0028(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.RepPropertyModOptim");
		return pStaticClass;
	}

};


// Class Basic.STBaseBuffCarrierInterface
// 0x0000 (0x0028 - 0x0028)
class USTBaseBuffCarrierInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBaseBuffCarrierInterface");
		return pStaticClass;
	}


	bool SetEndTime(int InstID, float EndTime);
	bool RemoveBuffBySkill(int SkillID, int LayerCount, class AActor* Causer);
	bool RemoveBuffByID(int BuffID, class AActor* Causer, int LayerCount, int CauseSkillID);
	bool HasSkillID(int SkillID);
	bool HasBuffID(int BuffID);
	TArray<int> GetBuffIDsBySkillID(int SkillID);
	float GetBuffDuration(int InstID, int CauseSkillID);
	class USTBuffSystemComponent* GetBuffComponent();
	bool ChangeBuffDuration(int InstID, float Duration);
	bool AddBuffBySkill(int SkillID, int LayerCount, class AActor* Causer, int Level);
	int AddBuffByID(int BuffID, class AActor* Causer, int LayerCount, int CauseSkillID, int Level);
};


// Class Basic.STBuff
// 0x0130 (0x0158 - 0x0028)
class USTBuff : public UObject
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET
	int                                                BuffID;                                                   // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0044(0x0004) MISSED OFFSET
	struct FString                                     BuffName;                                                 // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Desc;                                                     // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	int                                                LayerMax;                                                 // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	float                                              Duration;                                                 // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClientSyncInterval;                                       // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0074(0x0004) MISSED OFFSET
	TArray<float>                                      CDConfigArray;                                            // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bNeedSyncCD;                                              // 0x0088(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBuffClientSyncType                                ClientSyncType;                                           // 0x0089(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EBuffTargetType                                    TargetType;                                               // 0x008A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EBuffRefreshType                                   RefreshType;                                              // 0x008B(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EBuffReActionType                                  ReActionType;                                             // 0x008C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EMultiCauserHandleType                             MultiCauserHandleType;                                    // 0x008D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	EMultiSkillHandleType                              MultiSkillHandleType;                                     // 0x008E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               IsExecuteOnece;                                           // 0x008F(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               RemoveAllLayer;                                           // 0x0090(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x0091(0x0007) MISSED OFFSET
	TArray<class USTBuffTriggerBase*>                  TriggerBases;                                             // 0x0098(0x0010) (Edit, BlueprintVisible, ExportObject, ZeroConstructor)
	TArray<class USTBuffCheckConditionWrapper*>        Conditions;                                               // 0x00A8(0x0010) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, EditConst)
	TArray<class USTBuffAction*>                       Actions;                                                  // 0x00B8(0x0010) (Edit, BlueprintVisible, ExportObject, ZeroConstructor)
	EBuffShowInUIType                                  NeedShowBuffTypeInBuffList;                               // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x00C9(0x0003) MISSED OFFSET
	int                                                LocalizeDescID;                                           // 0x00CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FString                                     IconPath;                                                 // 0x00D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               IsClientOwnLife;                                          // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	bool                                               ExistForever;                                             // 0x00E1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char                                      UnknownData05[0x2];                                       // 0x00E2(0x0002) MISSED OFFSET
	int                                                TipsOnAddBuff;                                            // 0x00E4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, EditConst, IsPlainOldData)
	struct FString                                     TimeFormula;                                              // 0x00E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, EditConst)
	bool                                               bNeedTick;                                                // 0x00F8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x7];                                       // 0x00F9(0x0007) MISSED OFFSET
	TMap<class UObject*, int>                          InstancedNodeNameToMemoryMap;                             // 0x0100(0x0050) (ZeroConstructor)
	int                                                InstancedNodesTotalSize;                                  // 0x0150(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x4];                                       // 0x0154(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuff");
		return pStaticClass;
	}


	void Tick(class UActorComponent* BuffSystemComponent, int InstID, float DetalTime, float TimeSeconds, TArray<int>* TickActionList);
	void ResetActionExecute(class UActorComponent* BuffSystemComponent, int InstID);
	void OnCreate(class UActorComponent* BuffSystemComponent, int InstID);
	void Initialize(class UActorComponent* BuffSystemComponent, int InstID);
	void InitBuffAction();
	void End(class UActorComponent* BuffSystemComponent, int InstID);
	void Destroy(class UActorComponent* BuffSystemComponent, int InstID);
	bool ChangeNotify(class UActorComponent* BuffSystemComponent, int InstID);
};


// Class Basic.STBuffNodeInstanceData
// 0x0030 (0x0058 - 0x0028)
class USTBuffNodeInstanceData : public UObject
{
public:
	unsigned char                                      UnknownData00[0x18];                                      // 0x0028(0x0018) MISSED OFFSET
	class UActorComponent*                             CurOwnerActorComponent;                                   // 0x0040(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	int                                                CurInstID;                                                // 0x0048(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class USTBuff>                      OwnerBuff;                                                // 0x004C(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	int                                                ArrayIndex;                                               // 0x0054(0x0004) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffNodeInstanceData");
		return pStaticClass;
	}


	int GetBuffInstLevel();
};


// Class Basic.STBuffAction
// 0x0050 (0x00A8 - 0x0058)
class USTBuffAction : public USTBuffNodeInstanceData
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0058(0x0008) MISSED OFFSET
	EBuffEnabledRole                                   ActionRole;                                               // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0061(0x0003) MISSED OFFSET
	float                                              ExecuteDelay;                                             // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FBuffCheckConditionWrapperItem>      ConditionSettings;                                        // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FBuffTriggerWrapperItem>             TriggerSettings;                                          // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bEnableTick;                                              // 0x0088(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0089(0x0003) MISSED OFFSET
	float                                              Interval;                                                 // 0x008C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              FirstTickStartTime;                                       // 0x0090(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bTickByPeriod;                                            // 0x0094(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               AutoEnabled;                                              // 0x0095(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x0096(0x0002) MISSED OFFSET
	TArray<class UObject*>                             CacheSoftObject;                                          // 0x0098(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffAction");
		return pStaticClass;
	}


	struct FString ToString();
	void Tick(class UActorComponent* BuffSystemComponent, int InstID, float DetalTime);
	void SetEnabled(class UActorComponent* BuffSystemComponent, int InstID, bool Enabled);
	void ResetExecute(class UActorComponent* BuffSystemComponent, int InstID, bool IgnoreEnd);
	void OnTick(float DetalTime);
	void OnResetExecute(bool IgnoreEnd);
	void OnInitialize();
	void OnExecute();
	void OnEnd();
	void OnDestroy();
	void OnCheckLinkActionEnabled();
	void OnChangeNotify();
	void OnAsyncLoadSoftPathDone();
	bool IsRoleOK(class UActorComponent* OwnerComponent);
	void Initialize(class UActorComponent* BuffSystemComponent, int InstID);
	TEnumAsByte<ENetRole> GetRealOwnerRole();
	class AActor* GetOwner();
	class AActor* GetCauser();
	void Execute(class UActorComponent* BuffSystemComponent, int InstID);
	void End(class UActorComponent* BuffSystemComponent, int InstID);
	void Destroy(class UActorComponent* BuffSystemComponent, int InstID);
	void CheckLinkActionEnabled(class UActorComponent* BuffSystemComponent, int InstID);
	void ChangeNotify(class UActorComponent* BuffSystemComponent, int InstID);
};


// Class Basic.STBuffAction_Lua
// 0x0128 (0x01D0 - 0x00A8)
class USTBuffAction_Lua : public USTBuffAction
{
public:
	unsigned char                                      UnknownData00[0xC0];                                      // 0x00A8(0x00C0) MISSED OFFSET
	TMap<struct FString, struct FString>               ActionParams;                                             // 0x0168(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bEnableLuaPrivateData;                                    // 0x01B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x01B9(0x0007) MISSED OFFSET
	struct FString                                     LuaFilePath;                                              // 0x01C0(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffAction_Lua");
		return pStaticClass;
	}


	struct FString ToString();
	void OnTick(float DetalTime);
	void OnInitialize();
	void OnExecute();
	void OnEnd();
	void OnDestroy();
	void OnChangeNotify();
};


// Class Basic.STBuffCheckConditionWrapper
// 0x0028 (0x0080 - 0x0058)
class USTBuffCheckConditionWrapper : public USTBuffNodeInstanceData
{
public:
	EBuffEnabledRole                                   ExecuteRole;                                              // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0059(0x0007) MISSED OFFSET
	class USTBuffCondition*                            Condition;                                                // 0x0060(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	float                                              ConditionTickInterval;                                    // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Probality;                                                // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBuffConditionExecuteTimeType                      ExecuteTimeType;                                          // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsDoOnFalse;                                              // 0x0071(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsNeedTick;                                               // 0x0072(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsNeedExecute;                                            // 0x0073(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsSetFalseWhenExecute;                                    // 0x0074(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0075(0x0003) MISSED OFFSET
	float                                              ExecuteDelay;                                             // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x007C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffCheckConditionWrapper");
		return pStaticClass;
	}


	void Tick(class UActorComponent* BuffSystemComponent, int InstID, float DetalTime);
	void ResetExecute(class UActorComponent* BuffSystemComponent, int InstID, bool IgnoreEnd);
	void OnTick(float DetalTime);
	void OnInitialize();
	void OnDestroy();
	void OnConditionTrue();
	void OnConditionFalse();
	void OnChangeNotify();
	bool IsRoleOK(class UActorComponent* OwnerComponent);
	void InitLinkActionEnableState(class UActorComponent* BuffSystemComponent, int InstID);
	void Initialize(class UActorComponent* BuffSystemComponent, int InstID);
	TEnumAsByte<ENetRole> GetRealOwnerRole();
	void Execute(class UActorComponent* BuffSystemComponent, int InstID);
	void End(class UActorComponent* BuffSystemComponent, int InstID);
	void Destroy(class UActorComponent* BuffSystemComponent, int InstID);
	void CheckCondition();
	void ChangeNotify(class UActorComponent* BuffSystemComponent, int InstID);
};


// Class Basic.STBuffCondition
// 0x0030 (0x0058 - 0x0028)
class USTBuffCondition : public UObject
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0028(0x0020) MISSED OFFSET
	EBuffConditionAndOr                                AndOrPrev;                                                // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0049(0x0007) MISSED OFFSET
	class USTBuffNodeInstanceData*                     OwnerInstanceData;                                        // 0x0050(0x0008) (ZeroConstructor, Transient, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffCondition");
		return pStaticClass;
	}


	void OnResetExecute(bool IgnoreEnd);
	void OnInitialize();
	void OnEnd();
	void OnDestroy();
	class AActor* GetOwner();
	class AActor* GetCauser();
	class USTBuffCondition* Copy(class UObject* Outer);
	bool CheckIsTrue();
	void ChangeNotify();
};


// Class Basic.STBuffCondition_Lua
// 0x0128 (0x0180 - 0x0058)
class USTBuffCondition_Lua : public USTBuffCondition
{
public:
	unsigned char                                      UnknownData00[0xC0];                                      // 0x0058(0x00C0) MISSED OFFSET
	TMap<struct FString, struct FString>               ActionParams;                                             // 0x0118(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bEnableLuaPrivateData;                                    // 0x0168(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0169(0x0007) MISSED OFFSET
	struct FString                                     LuaFilePath;                                              // 0x0170(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffCondition_Lua");
		return pStaticClass;
	}


	void OnInitialize();
	void OnDestroy();
	bool CheckIsTrue();
};


// Class Basic.STBuffConditionComplex
// 0x0010 (0x0068 - 0x0058)
class USTBuffConditionComplex : public USTBuffCondition
{
public:
	TArray<class USTBuffCondition*>                    Conditions;                                               // 0x0058(0x0010) (Edit, BlueprintVisible, ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffConditionComplex");
		return pStaticClass;
	}


	void OnInitialize();
	void OnDestroy();
	class USTBuffCondition* Copy(class UObject* Outer);
	bool CheckIsTrue();
};


// Class Basic.STBuffConditionNot
// 0x0008 (0x0060 - 0x0058)
class USTBuffConditionNot : public USTBuffCondition
{
public:
	class USTBuffCondition*                            Condition;                                                // 0x0058(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffConditionNot");
		return pStaticClass;
	}


	void OnInitialize();
	void OnDestroy();
	class USTBuffCondition* Copy(class UObject* Outer);
	bool CheckIsTrue();
};


// Class Basic.STBuffConditionAction
// 0x0028 (0x00D0 - 0x00A8)
class USTBuffConditionAction : public USTBuffAction
{
public:
	class USTBuffCondition*                            Condition;                                                // 0x00A8(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	float                                              ConditionTickInterval;                                    // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Probality;                                                // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBuffConditionExecuteTimeType                      ExecuteTimeType;                                          // 0x00B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsDoOnFalse;                                              // 0x00B9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsNeedTick;                                               // 0x00BA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsNeedExecute;                                            // 0x00BB(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsSetFalseWhenExecute;                                    // 0x00BC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x00BD(0x0003) MISSED OFFSET
	TArray<struct FBuffConditionActionItem>            LinkActions;                                              // 0x00C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffConditionAction");
		return pStaticClass;
	}


	void OnTick(float DetalTime);
	void OnInitialize();
	void OnDestroy();
	void OnConditionTrue();
	void OnConditionFalse();
	void OnChangeNotify();
	void CheckCondition();
};


// Class Basic.STBuffEvent
// 0x0040 (0x0068 - 0x0028)
class USTBuffEvent : public UObject
{
public:
	unsigned char                                      UnknownData00[0x20];                                      // 0x0028(0x0020) MISSED OFFSET
	class USTBuffNodeInstanceData*                     OwnerInstanceData;                                        // 0x0048(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	EBuffEnabledRole                                   ExecuteRole;                                              // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bStateEvent;                                              // 0x0051(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x6];                                       // 0x0052(0x0006) MISSED OFFSET
	struct FString                                     StateSharedKey;                                           // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffEvent");
		return pStaticClass;
	}


	void TriggerEvent();
	struct FString ToString();
	void SetTimer(const struct FName& FunctionName, float InRate, bool InbLoop, float InFirstDelay);
	void OnInitialize();
	void OnEnd();
	void OnDestroy();
	bool IsRoleOK(class UActorComponent* OwnerComponent);
	TEnumAsByte<ENetRole> GetRealOwnerRole();
	class AActor* GetOwner();
	class AActor* GetCauser();
	class USTBuffEvent* Copy(class UObject* Outer);
	void ClearTimer(const struct FName& FunctionName);
	void ClearAllTimer();
};


// Class Basic.STBuffEvent_Lua
// 0x0128 (0x0190 - 0x0068)
class USTBuffEvent_Lua : public USTBuffEvent
{
public:
	unsigned char                                      UnknownData00[0xC0];                                      // 0x0068(0x00C0) MISSED OFFSET
	TMap<struct FString, struct FString>               ActionParams;                                             // 0x0128(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	bool                                               bEnableLuaPrivateData;                                    // 0x0178(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0179(0x0007) MISSED OFFSET
	struct FString                                     LuaFilePath;                                              // 0x0180(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffEvent_Lua");
		return pStaticClass;
	}


	struct FString ToString();
};


// Class Basic.STBuffEvent_Multi
// 0x0010 (0x0078 - 0x0068)
class USTBuffEvent_Multi : public USTBuffEvent
{
public:
	TArray<class USTBuffEvent*>                        Events;                                                   // 0x0068(0x0010) (Edit, BlueprintVisible, ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffEvent_Multi");
		return pStaticClass;
	}


	void OnInitialize();
	void OnEnd();
	void OnDestroy();
	class USTBuffEvent* Copy(class UObject* Outer);
};


// Class Basic.STBuffEvent_OnEnd
// 0x0000 (0x0068 - 0x0068)
class USTBuffEvent_OnEnd : public USTBuffEvent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffEvent_OnEnd");
		return pStaticClass;
	}

};


// Class Basic.STBuffSharedInterface
// 0x0000 (0x0028 - 0x0028)
class USTBuffSharedInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffSharedInterface");
		return pStaticClass;
	}


	void SetVectorShared(const struct FString& SharedName, const struct FVector& InValue);
	void SetUInt8Shared(const struct FString& SharedName, unsigned char InValue);
	void SetTargetShared(const struct FString& SharedName, TArray<class AActor*> InActors);
	void SetStringShared(const struct FString& SharedName, const struct FString& InValue);
	void SetRotatorShared(const struct FString& SharedName, const struct FRotator& InValue);
	void SetNameShared(const struct FString& SharedName, const struct FName& InValue);
	void SetInt32Shared(const struct FString& SharedName, int InValue);
	void SetFloatShared(const struct FString& SharedName, float InValue);
	void SetBooleanShared(const struct FString& SharedName, bool InValue);
	void RemoveShared(const struct FString& SharedName);
	bool GetVectorShared(const struct FString& SharedName, struct FVector* OutValue);
	bool GetUInt8Shared(const struct FString& SharedName, unsigned char* OutValue);
	bool GetTargetShared(const struct FString& SharedName, TArray<class AActor*>* OutActors);
	bool GetStringShared(const struct FString& SharedName, struct FString* OutValue);
	bool GetRotatorShared(const struct FString& SharedName, struct FRotator* OutValue);
	bool GetNameShared(const struct FString& SharedName, struct FName* OutValue);
	bool GetInt32Shared(const struct FString& SharedName, int* OutValue);
	bool GetFloatShared(const struct FString& SharedName, float* OutValue);
	bool GetBooleanShared(const struct FString& SharedName, bool* OutValue);
};


// Class Basic.STBuffSystemComponent
// 0x0328 (0x04A0 - 0x0178)
class USTBuffSystemComponent : public UActorComponent
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0178(0x0008) MISSED OFFSET
	float                                              RPCSyncInterval;                                          // 0x0180(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0184(0x0004) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnClientAddBuffEvent;                                     // 0x0188(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnClientRemoveBuffEvent;                                  // 0x0198(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnClientUpdateBuffEvent;                                  // 0x01A8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnAddBuffEvent;                                           // 0x01B8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnRemoveBuffEvent;                                        // 0x01C8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnUpdateBuffEvent;                                        // 0x01D8(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	TMap<int, class UUAEBlackboard*>                   BuffBlackboardMap;                                        // 0x01E8(0x0050) (ZeroConstructor)
	struct FBuffIncNetArray                            SyncBriefs;                                               // 0x0238(0x0020) (Net)
	struct FBuffIncNetArray                            SyncRefBriefs;                                            // 0x0258(0x0020)
	struct FBuffIncNetArray                            OwnerSyncBriefs;                                          // 0x0278(0x0020) (Net)
	struct FBuffIncNetArray                            OwnerSyncRefBriefs;                                       // 0x0298(0x0020)
	struct FBuffIncNetArray                            DsBuffBriefs;                                             // 0x02B8(0x0020) (Net)
	unsigned char                                      UnknownData02[0x50];                                      // 0x02D8(0x0050) UNKNOWN PROPERTY: SetProperty Basic.STBuffSystemComponent.BriefRemoveInstIds
	TMap<struct FBuffReplaceData, struct FBuffReplaceData> BuffReplaceData;                                          // 0x0328(0x0050) (ZeroConstructor)
	unsigned char                                      UnknownData03[0x128];                                     // 0x0378(0x0128) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffSystemComponent");
		return pStaticClass;
	}


	void UpdateClientBuff(struct FBuffSyncBrief* Brief);
	bool SetEndTime(int InstID, float EndTime);
	bool SetBuffReplaceData(const struct FBuffReplaceData& From, const struct FBuffReplaceData& To);
	bool RemoveBuffBySkill(int SkillID, int LayerCount, class AActor* Causer);
	void RemoveBuff(int BuffID, int LayerCount, class AActor* Causer, int CauseSkillID);
	void RemoveAllBuffsWithExcludeArray(TArray<int> InExcludeArry);
	void RemoveAllBuffs(bool bClearAll);
	void OnUpdateBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	void OnRep_SyncBriefs();
	void OnRep_OwnerSyncBriefs();
	void OnRemoveBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	void OnClientUpdateBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	void OnClientRemoveBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	void OnClientAddBuffEvent__DelegateSignature(int BuffID, int SkillID, int InstID);
	void OnAddBuffEvent__DelegateSignature(int BuffID, int SkillID, bool IsExist, class AActor* Causer);
	bool IsCDOK(int InstID, int Index);
	bool IsBuffInstExist(int InstID);
	bool HasSkillID(int SkillID);
	bool HasBuff(int BuffID);
	class UBuffConfigSubsystem* GetSubsystem();
	class USTBuff* GetSTBuffByBuffID(int BuffID);
	TEnumAsByte<ENetRole> GetRealOwnerRoleSafety();
	struct FBuffReplaceData GetBuffReplaceDataByID(int ID, bool bBuffInst);
	int GetBuffLayerCount(int InstID, int CauseSkillID);
	TArray<struct FBuffSyncBrief> GetBuffInfoBySkillID(int SkillID);
	TArray<struct FBuffSyncBrief> GetBuffInfoByBuffID(int BuffID);
	bool GetBuffInfo(int InstID, struct FBuffSyncBrief* OutBuff);
	TArray<int> GetBuffIDsBySkillID(int SkillID);
	float GetBuffDuration(int InstID, int CauseSkillID);
	float GetBuffDSEndTime(int InstID, int CauseSkillID);
	TArray<float> GetBuffCDInfo(int InstID);
	TArray<struct FBuffSyncBrief> GetAllBuffInfo();
	void DoCooldown(int InstID, int Index, bool bReset);
	void ClearBuffs();
	bool ChangeLevel(int InstID, int NewLevel);
	bool ChangeDuration(int InstID, float Duration);
	bool AddBuffBySkill(int SkillID, int LayerCount, class AActor* Causer, int Level);
	int AddBuff(int BuffID, class AActor* Causer, int LayerCount, int CauseSkillID, int Level);
};


// Class Basic.STBuffTriggerBase
// 0x0018 (0x0070 - 0x0058)
class USTBuffTriggerBase : public USTBuffNodeInstanceData
{
public:
	bool                                               bTriggerOnCreate;                                         // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBuffEnabledRole                                   ExecuteRole;                                              // 0x0059(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x005A(0x0006) MISSED OFFSET
	struct FTriggerConditionConfig                     ConditionConfig;                                          // 0x0060(0x0010) (Edit, BlueprintVisible)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffTriggerBase");
		return pStaticClass;
	}


	void Tick(class UActorComponent* BuffSystemComponent, int InstID, float DeltaTime);
	void ResetExecute(class UActorComponent* BuffSystemComponent, int InstID);
	void OnTriggerCreate();
	void OnTick(float DeltaTime);
	void OnInitialize();
	void OnEnd();
	void OnDestroy();
	void OnCreate(class UActorComponent* BuffSystemComponent, int InstID);
	bool IsRoleOK(class UActorComponent* OwnerComponent);
	bool IsNeedTick();
	void InitLinkActionEnableState(class UActorComponent* BuffSystemComponent, int InstID);
	void Initialize(class UActorComponent* BuffSystemComponent, int InstID);
	TEnumAsByte<ENetRole> GetRealOwnerRole();
	void End(class UActorComponent* BuffSystemComponent, int InstID);
	void Destroy(class UActorComponent* BuffSystemComponent, int InstID);
};


// Class Basic.STBuffTrigger_Event
// 0x0008 (0x0078 - 0x0070)
class USTBuffTrigger_Event : public USTBuffTriggerBase
{
public:
	class USTBuffEvent*                                Event;                                                    // 0x0070(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffTrigger_Event");
		return pStaticClass;
	}

};


// Class Basic.STBuffTrigger_OnAdd
// 0x0000 (0x0070 - 0x0070)
class USTBuffTrigger_OnAdd : public USTBuffTriggerBase
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffTrigger_OnAdd");
		return pStaticClass;
	}

};


// Class Basic.STBuffTrigger_Timer
// 0x0008 (0x0078 - 0x0070)
class USTBuffTrigger_Timer : public USTBuffTriggerBase
{
public:
	float                                              TickInterval;                                             // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0074(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STBuffTrigger_Timer");
		return pStaticClass;
	}

};


// Class Basic.UStringMap
// 0x0050 (0x0078 - 0x0028)
class UUStringMap : public UObject
{
public:
	struct FStringMap                                  Map;                                                      // 0x0028(0x0050)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UStringMap");
		return pStaticClass;
	}

};


// Class Basic.STExtraNetPriorityConfig
// 0x00B8 (0x00E8 - 0x0030)
class USTExtraNetPriorityConfig : public UWorldSubsystem
{
public:
	bool                                               ExtraNetPriorityEnabled;                                  // 0x0030(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	TMap<ESTExtraNetPriorityFlags, float>              ExtraNetPriorityFactor;                                   // 0x0038(0x0050) (ZeroConstructor, Config)
	bool                                               EnemyExtraNetPriorityEnabled;                             // 0x0088(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0089(0x0003) MISSED OFFSET
	float                                              EnemyExtraNetPriorityFactor;                              // 0x008C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	TMap<ESTExtraNetPriorityIssueID, ESTExtraNetPriorityFlags> NetPriorityIssue;                                         // 0x0090(0x0050) (ZeroConstructor, Config)
	float                                              MoveExtraNetPriorityVelocitySquared;                      // 0x00E0(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STExtraNetPriorityConfig");
		return pStaticClass;
	}

};


// Class Basic.STExtraNetPriorityInterface
// 0x0000 (0x0028 - 0x0028)
class USTExtraNetPriorityInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.STExtraNetPriorityInterface");
		return pStaticClass;
	}

};


// Class Basic.DataTableRowDesc
// 0x0070 (0x0098 - 0x0028)
class UDataTableRowDesc : public UObject
{
public:
	unsigned char                                      UnknownData00[0x70];                                      // 0x0028(0x0070) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.DataTableRowDesc");
		return pStaticClass;
	}

};


// Class Basic.DataTableProxy
// 0x0168 (0x0190 - 0x0028)
class UDataTableProxy : public UObject
{
public:
	TArray<class UDataTable*>                          ModDataTables;                                            // 0x0028(0x0010) (ZeroConstructor)
	class UDataTable*                                  DataTable;                                                // 0x0038(0x0008) (ZeroConstructor, IsPlainOldData)
	class UBCDataTable*                                BlockTable;                                               // 0x0040(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x140];                                     // 0x0048(0x0140) MISSED OFFSET
	class UDataTableRowDesc*                           Desc;                                                     // 0x0188(0x0008) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.DataTableProxy");
		return pStaticClass;
	}

};


// Class Basic.TableManagerSubsystem
// 0x0050 (0x0080 - 0x0030)
class UTableManagerSubsystem : public UGameInstanceSubsystem
{
public:
	struct FString                                     BaseTableRelativeDir;                                     // 0x0030(0x0010) (ZeroConstructor, Config)
	struct FString                                     ModTableRelativeDir;                                      // 0x0040(0x0010) (ZeroConstructor, Config)
	struct FString                                     TableRelativeDir;                                         // 0x0050(0x0010) (ZeroConstructor, Config)
	struct FString                                     ManualTableDirectory;                                     // 0x0060(0x0010) (ZeroConstructor, Config)
	struct FString                                     CurrentModName;                                           // 0x0070(0x0010) (ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.TableManagerSubsystem");
		return pStaticClass;
	}


	static bool SetTableStringDataField(const struct FName& tableName, const struct FString& Key, const struct FString& Field, const struct FString& NewValue);
	void SetModName(const struct FString& ModName);
	class UDataTableProxy* GetTableProxy(const struct FName& tableName, bool bTempory, const struct FName& SystemName, const struct FName& SubModName, bool bPreLoadPathCompression);
	static bool GetTableDataField(const struct FString& tableName, const struct FTableRowBase& Key, const struct FString& Field, struct FTableRowBase* Out);
	static bool GetTableData(const struct FString& tableName, const struct FString& Key, struct FTableRowBase* OutRow);
};


// Class Basic.TickOptimizationAnimComponent
// 0x0038 (0x01B0 - 0x0178)
class UTickOptimizationAnimComponent : public UActorComponent
{
public:
	bool                                               EnableTickOptimization;                                   // 0x0178(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ETickOptimizationAnimUROMode                       AnimUpdateRateOptimizationsMode;                          // 0x0179(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x017A(0x0006) MISSED OFFSET
	TArray<float>                                      FramesSkippedScreenSizeThresholds;                        // 0x0180(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int>                                        LODToFramesSkipped;                                       // 0x0190(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                NonRenderedFramesSkipped;                                 // 0x01A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                MaxFramesSkippedForInterpolation;                         // 0x01A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bForceEnableAnimUpdateRateOptimizations;                  // 0x01A8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x01A9(0x0007) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.TickOptimizationAnimComponent");
		return pStaticClass;
	}


	bool ShouldForceEnableAnimUpdateRateOptimizations();
	void SetNonRenderedFramesSkipped(int InNonRenderedFramesSkipped);
	void SetMaxFramesSkippedForInterpolation(int InMaxFramesSkippedForInterpolation);
	void SetLODToFramesSkipped(TArray<int> InLODToFramesSkipped);
	void SetFramesSkippedScreenSizeThresholds(TArray<float> InFramesSkippedScreenSizeThresholds);
	void SetForceEnableAnimUpdateRateOptimizations(bool bInForceEnableAnimUpdateRateOptimizations);
	void SetAnimUpdateRateOptimizationsMode(ETickOptimizationAnimUROMode InAnimUpdateRateOptimizationsMode);
	void RegisterDynamicSkinnedMeshComponent(class USkinnedMeshComponent* SkinnedMeshComponent);
	int GetNonRenderedFramesSkipped();
	int GetMaxFramesSkippedForInterpolation();
	TArray<int> GetLODToFramesSkipped();
	TArray<float> GetFramesSkippedScreenSizeThresholds();
	ETickOptimizationAnimUROMode GetAnimUpdateRateOptimizationsMode();
};


// Class Basic.TickOptimizationFocusComponent
// 0x0010 (0x03B0 - 0x03A0)
class UTickOptimizationFocusComponent : public USceneComponent
{
public:
	class UTickOptimizationSubsystem*                  Subsystem;                                                // 0x03A0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.TickOptimizationFocusComponent");
		return pStaticClass;
	}


	bool ShouldTrack();
};


// Class Basic.TickOptimizationSubsystem
// 0x0078 (0x00A8 - 0x0030)
class UTickOptimizationSubsystem : public UWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	TArray<class UTickOptimizationFocusComponent*>     Focuses;                                                  // 0x0038(0x0010) (ExportObject, ZeroConstructor, Transient)
	TArray<class UTickOptimizationTargetComponent*>    SphereRangeTargets;                                       // 0x0048(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x20];                                      // 0x0058(0x0020) MISSED OFFSET
	TArray<class UTickOptimizationTargetComponent*>    SphereZoneTargets;                                        // 0x0078(0x0010) (ExportObject, ZeroConstructor, Transient)
	unsigned char                                      UnknownData02[0x10];                                      // 0x0088(0x0010) MISSED OFFSET
	TArray<class UTickOptimizationTargetComponent*>    UpdatedTargets;                                           // 0x0098(0x0010) (ExportObject, ZeroConstructor, Transient)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.TickOptimizationSubsystem");
		return pStaticClass;
	}

};


// Class Basic.TickOptimizationTargetComponent
// 0x0090 (0x0430 - 0x03A0)
class UTickOptimizationTargetComponent : public USceneComponent
{
public:
	class UTickOptimizationSubsystem*                  Subsystem;                                                // 0x03A0(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x03A8(0x0008) MISSED OFFSET
	TArray<class UActorComponent*>                     TickControlledComponents;                                 // 0x03B0(0x0010) (ExportObject, ZeroConstructor, Transient)
	bool                                               EnableTickOptimization;                                   // 0x03C0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	ETickOptimizationDistanceMode                      DistanceMode;                                             // 0x03C1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x03C2(0x0002) MISSED OFFSET
	float                                              SphereRadius;                                             // 0x03C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              BufferSize;                                               // 0x03C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x03CC(0x0004) MISSED OFFSET
	TArray<float>                                      MidZoneSizes;                                             // 0x03D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bActorTickControl;                                        // 0x03E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bActorTickChange;                                         // 0x03E1(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bComponentsTickControl;                                   // 0x03E2(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bComponentsTickChange;                                    // 0x03E3(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bForceExecuteFirstTick;                                   // 0x03E4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x03E5(0x0003) MISSED OFFSET
	TArray<struct FTickOptimizationTickSettings>       TickSettings;                                             // 0x03E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               bForced;                                                  // 0x03F8(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x03F9(0x0003) MISSED OFFSET
	int                                                TickZone;                                                 // 0x03FC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FScriptMulticastDelegate                    OnTickChanged;                                            // 0x0400(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnTickZoneChanged;                                        // 0x0410(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnTickEnabledChanged;                                     // 0x0420(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.TickOptimizationTargetComponent");
		return pStaticClass;
	}


	bool ShouldForceExecuteFirstTick();
	void SetTickSettings(TArray<struct FTickOptimizationTickSettings> InTickSettings);
	void SetSphereRadius(float InRadius);
	void SetMidZoneSizes(TArray<float> InMidZoneSizes);
	void SetForceExecuteFirstTick(bool bInForceExecuteFirstTick);
	void SetDistanceMode(ETickOptimizationDistanceMode InDistanceMode);
	void SetComponentsTickControl(bool bInComponentsTickControl);
	void SetBufferSize(float InBufferSize);
	void SetActorTickControl(bool bInActorTickControl);
	void RemoveComponentTickControl(class UActorComponent* Component);
	void Release();
	bool IsForced();
	bool IsComponentsTickControl();
	bool IsActorTickControl();
	int GetTickZone();
	TArray<struct FTickOptimizationTickSettings> GetTickSettings();
	float GetSphereRadius();
	TArray<float> GetMidZoneSizes();
	ETickOptimizationDistanceMode GetDistanceMode();
	float GetBufferSize();
	void Force(int InZone);
	void AddComponentTickControl(class UActorComponent* Component);
};


// Class Basic.UAEBuffPoolSubsystem
// 0x0050 (0x0080 - 0x0030)
class UUAEBuffPoolSubsystem : public UWorldSubsystem
{
public:
	TMap<struct FString, class USTBuff*>               BuffInstancedTemplateMap;                                 // 0x0030(0x0050) (ExportObject, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAEBuffPoolSubsystem");
		return pStaticClass;
	}

};


// Class Basic.UAEGameEngine
// 0x0050 (0x0EC0 - 0x0E70)
class UUAEGameEngine : public UGameEngine
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0E70(0x0010) MISSED OFFSET
	class UBackendHUD*                                 AssociatedBackendHUD;                                     // 0x0E80(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xC];                                       // 0x0E88(0x000C) MISSED OFFSET
	bool                                               bEnableAutoStat;                                          // 0x0E94(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableAutoTickDeltaThreshold;                            // 0x0E95(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0E96(0x0002) MISSED OFFSET
	float                                              AutoTickDeltaThresholdFactor;                             // 0x0E98(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              StatCollection_AvgTickDeltaThreshold;                     // 0x0E9C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              AutoStat_AvgTickDeltaThreshold;                           // 0x0EA0(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              AutoStat_StartTime;                                       // 0x0EA4(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x0EA8(0x0004) MISSED OFFSET
	float                                              AutoStat_Duration_Engine;                                 // 0x0EAC(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              AutoStat_Duration_PhysX;                                  // 0x0EB0(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData04[0xC];                                       // 0x0EB4(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAEGameEngine");
		return pStaticClass;
	}

};


// Class Basic.BPTable
// 0x00B0 (0x00D8 - 0x0028)
class UBPTable : public UObject
{
public:
	struct FString                                     BPTableName;                                              // 0x0028(0x0010) (BlueprintVisible, ZeroConstructor)
	TMap<int, struct FBPTableItem>                     BPTableItemMap;                                           // 0x0038(0x0050) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TMap<int, struct FBPTableItem>                     BPTableItemMap_Mod;                                       // 0x0088(0x0050) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.BPTable");
		return pStaticClass;
	}


	struct FString GetWrapperPath(int ID);
	class UClass* GetWrapperClass(int ID);
	struct FString GetPath(int ID, bool IsLobby, bool bForceLobby);
	class UObject* GetObject(int ID, class UObject* Outer, bool IsLobby, bool IsLowDevice);
	class UObject* GetModObject(int ID, class UObject* Outer, bool IsLobby);
	class UClass* GetModClass(int ID, bool IsLobby);
	class UClass* GetCustom1Class(int ID);
	class UClass* GetClass(int ID, bool IsLobby, bool IsLowDevice);
	void ConvertPath(int ID);
};


// Class Basic.UAELoadedClassManager
// 0x0380 (0x03A8 - 0x0028)
class UUAELoadedClassManager : public UObject
{
public:
	TMap<struct FString, class UBPTable*>              BPTableMap;                                               // 0x0028(0x0050) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TMap<struct FString, class UBPTable*>              BPTableMap_Mod;                                           // 0x0078(0x0050) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TMap<int, struct FString>                          BPTableNameMap;                                           // 0x00C8(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TMap<struct FName, struct FTableNameToName>        BPTableNameToNameMap;                                     // 0x0118(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	struct FString                                     LoadedClassManagerClassName;                              // 0x0168(0x0010) (ZeroConstructor, Config)
	unsigned char                                      UnknownData00[0x1C8];                                     // 0x0178(0x01C8) MISSED OFFSET
	TMap<class UObject*, struct FSoftClassPath>        AsyncLoadClassDict;                                       // 0x0340(0x0050) (ZeroConstructor, Transient)
	unsigned char                                      UnknownData01[0x18];                                      // 0x0390(0x0018) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAELoadedClassManager");
		return pStaticClass;
	}


	void InitTableData();
	void InitialModTableItemMap();
	void InitBPTableMap_Mod();
	void InitBPTableMap();
	void HandleTableModNameChanged(const struct FString& InModName);
	struct FString GetWrapperPath(const struct FString& BPTableName, int ID);
	class UClass* GetWrapperClass(const struct FString& BPTableName, int ID);
	struct FString GetPath(const struct FString& BPTableName, int ID, bool IsLobby, bool bForceLobby);
	class UObject* GetObject(const struct FString& BPTableName, int ID, class UObject* Outer, bool IsLobby, bool IsLowDevice);
	static int GetExactDeviceLevel();
	static int GetDeviceLevel();
	class UClass* GetCustom1Class(const struct FString& BPTableName, int ID);
	struct FString GetClassLoadingPath(const struct FString& BPTableName, int ID, bool IsLobby);
	class UClass* GetClass(const struct FString& BPTableName, int ID, bool IsLobby, bool IsLowDevice);
	struct FString GetBPTableName(int Type);
	void GetAssetByAssetReferenceAsync(const struct FSoftObjectPath& AssetReference, const struct FScriptDelegate& AssetLoadSuccessDelegate);
	void GetAssetAsyncWithStringForManage(const struct FSoftObjectPath& AssetReference, const struct FString& InputString, const struct FScriptDelegate& AssetLoadSuccessDelegate);
	static class UUAELoadedClassManager* Get();
	class UBPTable* CreateAndAddBPTable_Mod(const struct FString& BPTableName);
	class UBPTable* CreateAndAddBPTable(const struct FString& BPTableName);
	void ClearModTableItemMap();
	void ClearBPTable_Mod();
	void ClearBPTable();
	void ClearAssetByAssetReferenceAsync(const struct FScriptDelegate& AssetLoadSuccessDelegate);
	void ClearAllHandle();
	void ClearAllData();
};


// Class Basic.UAEMeshComponent
// 0x0050 (0x13A0 - 0x1350)
class UUAEMeshComponent : public USkeletalMeshComponent
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x1350(0x0050) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAEMeshComponent");
		return pStaticClass;
	}


	void TriggerCacheMaterialParameterNameIndices();
	void RemoveDisableClothRequest(const struct FString& InSource);
	int GetPredictedLODLevel();
	struct FString GetAnimUpdateParamsInfo();
	void AddDisableClothRequest(const struct FString& InSource);
};


// Class Basic.UAENetConnection
// 0x0370 (0x35A78 - 0x35708)
class UUAENetConnection : public UIpConnection
{
public:
	unsigned char                                      UnknownData00[0x104];                                     // 0x35708(0x0104) MISSED OFFSET
	int                                                InitialHandshakeTimeoutNumThreshold;                      // 0x3580C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x35810(0x0004) MISSED OFFSET
	int                                                ActorChannelProcessBunchErrorNumThreshold_Server_Global;  // 0x35814(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                ActorChannelProcessBunchErrorNumThreshold_Client_Global;  // 0x35818(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                ActorChannelProcessBunchErrorNumThreshold_Client_PerActor;// 0x3581C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x50];                                      // 0x35820(0x0050) MISSED OFFSET
	bool                                               bEnableHTTPDNS;                                           // 0x35870(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x35871(0x0007) MISSED OFFSET
	struct FString                                     HTTPDNSServerAddr;                                        // 0x35878(0x0010) (ZeroConstructor, Config)
	float                                              HTTPDNSResponseTimeout;                                   // 0x35888(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData04[0xC];                                       // 0x3588C(0x000C) MISSED OFFSET
	float                                              CheckLevelInitializedTime;                                // 0x35898(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              CheckLevelActorsOvertime;                                 // 0x3589C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              TempCheckLevelInitializedTime;                            // 0x358A0(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x358A4(0x0004) MISSED OFFSET
	TMap<struct FName, struct FUnLoadLevelActorCollection> UnLevelInitActors;                                        // 0x358A8(0x0050) (ZeroConstructor)
	class UNetRelevancyGroup*                          RelevancyGroup;                                           // 0x358F8(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x100];                                     // 0x35900(0x0100) MISSED OFFSET
	TArray<struct FPendingRegionNetworkObject>         PendingRegionNetworkObjects;                              // 0x35A00(0x0010) (ZeroConstructor)
	float                                              MinRegionActorTickDelta;                                  // 0x35A10(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              MaxRegionActorTickDelta;                                  // 0x35A14(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData07[0xC];                                       // 0x35A18(0x000C) MISSED OFFSET
	bool                                               EnableWeakNetUpdate;                                      // 0x35A24(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData08[0x3];                                       // 0x35A25(0x0003) MISSED OFFSET
	float                                              MinWeakNetUpdateDelay;                                    // 0x35A28(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              MaxWeakNetUpdateDelay;                                    // 0x35A2C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              SquareSegmentSize;                                        // 0x35A30(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              MaxSegmentDistance;                                       // 0x35A34(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MaxObjectNumInSegments;                                   // 0x35A38(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData09[0x15];                                      // 0x35A3C(0x0015) MISSED OFFSET
	bool                                               bRecreateSocketOnLost;                                    // 0x35A51(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData10[0x12];                                      // 0x35A52(0x0012) MISSED OFFSET
	float                                              UpdateClientPingTimeThreshold;                            // 0x35A64(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData11[0x10];                                      // 0x35A68(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAENetConnection");
		return pStaticClass;
	}


	bool IsClosed();
	bool HasSameRegion(const struct FVector& OldLoc, const struct FVector& NewLoc);
	void ForceRefreshRegionWeakNetUpdateObjects(float WeakNetConsiderFrequency);
};


// Class Basic.UAENetDriver
// 0x0168 (0x0B68 - 0x0A00)
class UUAENetDriver : public UIpNetDriver
{
public:
	float                                              NetCullChangeTime;                                        // 0x0A00(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableCollectNetStats;                                   // 0x0A04(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bEnableResetNetStats;                                     // 0x0A05(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x0A06(0x0002) MISSED OFFSET
	TArray<struct FRPCShareSerializationFunctionPresetConfig> RPCShareSerializationFunctionPresetConfigs;               // 0x0A08(0x0010) (ZeroConstructor, Config)
	unsigned char                                      UnknownData01[0x150];                                     // 0x0A18(0x0150) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAENetDriver");
		return pStaticClass;
	}

};


// Class Basic.UAETableManager
// 0x08B0 (0x08D8 - 0x0028)
class UUAETableManager : public UObject
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x0028(0x0008) MISSED OFFSET
	struct FString                                     TableRelativeDir;                                         // 0x0030(0x0010) (ZeroConstructor, Config)
	TArray<struct FName>                               TablesNeedReleasedInBattle;                               // 0x0040(0x0010) (ZeroConstructor, Config)
	struct FString                                     ManualTableDirectory;                                     // 0x0050(0x0010) (ZeroConstructor, Config)
	unsigned char                                      UnknownData01[0x2C0];                                     // 0x0060(0x02C0) MISSED OFFSET
	TArray<class UUAEDataTable*>                       TableObjList;                                             // 0x0320(0x0010) (ZeroConstructor)
	class UWorld*                                      CurWorld;                                                 // 0x0330(0x0008) (ZeroConstructor, IsPlainOldData)
	TMap<struct FName, TWeakObjectPtr<class UUAEDataTable>> TableObjMap;                                              // 0x0338(0x0050) (ZeroConstructor)
	TMap<struct FName, TWeakObjectPtr<class UUAEDataTable>> TableObjMap_Mod;                                          // 0x0388(0x0050) (ZeroConstructor)
	struct FScriptMulticastDelegate                    OnTableCreateInFighting;                                  // 0x03D8(0x0010) (ZeroConstructor, InstancedReference)
	unsigned char                                      UnknownData02[0x168];                                     // 0x03E8(0x0168) MISSED OFFSET
	struct FString                                     PathCompressionConfigsPath;                               // 0x0550(0x0010) (ZeroConstructor, Config)
	bool                                               bIsPathCompression;                                       // 0x0560(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bIsPathCompressionCache;                                  // 0x0561(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData03[0x2];                                       // 0x0562(0x0002) MISSED OFFSET
	int                                                PathCompressionCacheMaxSize;                              // 0x0564(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bTranslationFallBackUnloadDuplicate;                      // 0x0568(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bShrinkTranslationMap;                                    // 0x0569(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bSpeedUpLoadLocalizationText;                             // 0x056A(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bAsyncLoadLocalizationTable;                              // 0x056B(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bLoadPathCompressionCfgWhenReadTable;                     // 0x056C(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	bool                                               bGenerateTrieTreeFromDict;                                // 0x056D(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x056E(0x0002) MISSED OFFSET
	TArray<struct FString>                             TableToPreLoadPathCompression;                            // 0x0570(0x0010) (ZeroConstructor, Config)
	bool                                               bEnableTablePreload;                                      // 0x0580(0x0001) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x0581(0x0007) MISSED OFFSET
	TArray<struct FName>                               TableToPreLoad;                                           // 0x0588(0x0010) (ZeroConstructor, Config)
	TArray<struct FName>                               TableToMmapMigrate;                                       // 0x0598(0x0010) (ZeroConstructor, Config)
	int                                                TablePreloadMaxRetryCount;                                // 0x05A8(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData06[0xC];                                       // 0x05AC(0x000C) MISSED OFFSET
	struct FString                                     BaseTableRelativeDir;                                     // 0x05B8(0x0010) (ZeroConstructor, Config)
	struct FString                                     ModTableRelativeDir;                                      // 0x05C8(0x0010) (ZeroConstructor, Config)
	struct FString                                     SplitModTableRelativeDir;                                 // 0x05D8(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             BaseModTableConfig;                                       // 0x05E8(0x0010) (ZeroConstructor, Config)
	TArray<struct FName>                               LobbyTableToLoadInMainCity;                               // 0x05F8(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             ModListToLoadTranslation;                                 // 0x0608(0x0010) (ZeroConstructor, Config)
	TMap<struct FName, class UModTable*>               ModTableMap;                                              // 0x0618(0x0050) (ZeroConstructor)
	TMap<struct FName, TWeakObjectPtr<class UUAEDataTable>> ModTableObjMap;                                           // 0x0668(0x0050) (ZeroConstructor)
	TArray<class UUAEDataTable*>                       InGameTableObjList;                                       // 0x06B8(0x0010) (ZeroConstructor)
	TMap<struct FName, bool>                           CheckNeedModMap;                                          // 0x06C8(0x0050) (ZeroConstructor)
	struct FString                                     CurrentModName;                                           // 0x0718(0x0010) (ZeroConstructor)
	struct FString                                     EmptyModName;                                             // 0x0728(0x0010) (ZeroConstructor)
	TMap<struct FString, class UBaseTableResMap*>      LoadedTableMap;                                           // 0x0738(0x0050) (ZeroConstructor)
	TMap<struct FString, bool>                         CheckMapTable;                                            // 0x0788(0x0050) (ZeroConstructor)
	unsigned char                                      UnknownData07[0x100];                                     // 0x07D8(0x0100) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UAETableManager");
		return pStaticClass;
	}


	void ReleaseTable(const struct FName& TableFName);
	void PreloadDataTablesAsync();
	class UUAEDataTable* GetTablePtr_Mod(const struct FName& tableName);
	class UUAEDataTable* GetTablePtr(const struct FName& tableName, bool bCheckModTable);
	class UBaseTableResMap* GetTableMap(const struct FString& tableName);
	static bool GetTableData(const struct FString& tableName, const struct FString& Key, struct FTableRowBase* OutRow);
	static class UUAETableManager* GetInstance();
	static struct FString GetDomainByID(int ID);
	static class UUAEDataTable* GetDataTableStatic_Mod(const struct FString& tableName);
	static class UUAEDataTable* GetDataTableStatic(const struct FString& tableName);
	class UDataTableProxy* GetDataTableProxy(const struct FName& tableName, bool bTempory, const struct FName& SystemName, const struct FName& SubModName);
};


// Class Basic.UELanguageUtilityMethods
// 0x0000 (0x0028 - 0x0028)
class UUELanguageUtilityMethods : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UELanguageUtilityMethods");
		return pStaticClass;
	}


	static void SetDownLoadLanguageName(const struct FString& Language);
	static bool IsJaguar();
	static struct FString GetPublishRegion();
	static struct FString GetDownLoadLanguageName();
	static struct FString GetCurrentLanguageName();
	static struct FString ConvertLanguageName(const struct FString& prelanguage);
	static bool CheckLocalizationExist();
};


// Class Basic.UEMathUtilityMethods
// 0x0000 (0x0028 - 0x0028)
class UUEMathUtilityMethods : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UEMathUtilityMethods");
		return pStaticClass;
	}


	static void VectorNormalizeMultiple(const struct FVector& v1, float Multiple, struct FVector* Out);
	static void VectorMultiple(const struct FVector& v1, float Multiple, struct FVector* Out);
	static void VectorMinus(const struct FVector& v1, const struct FVector& v2, struct FVector* Out);
	static void VectorAdditive(const struct FVector& v1, const struct FVector& v2, struct FVector* Out);
	static bool FilterOKForCurrentMode(unsigned char ModeType, int ModeOpenFlag, const struct FString& ModeTypes);
	static void Conv_VectorToRotator(const struct FVector& Vec, struct FRotator* Out);
	static float CalculateAngleToTargetAngle(float StartAngle, float targetAngle, float StepAngle, EAngleRotationDirectionType Dir);
	static int BKDRHash(const struct FString& StrToHash, int Mod);
	static float AngleDis(float angleA, float angleB);
};


// Class Basic.UEPathUtilityMethods
// 0x0000 (0x0028 - 0x0028)
class UUEPathUtilityMethods : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.UEPathUtilityMethods");
		return pStaticClass;
	}


	static bool IsPathExist(const struct FString& HandlePath);
	static bool IsAvatarResPathExistRetODPakName(const struct FString& HandlePath, struct FString* OutODPakName);
	static bool IsAvatarResPathExist(const struct FString& HandlePath);
	static TArray<struct FString> GetPassiveDownloadResourcePaths();
	static TArray<int> GetPassiveDownloadResourceIDList();
	static struct FString GetODPakFileName(const struct FString& InODPakPath);
	static struct FString GetModName(class UObject* WorldContext);
	static void GetFullModName(class UObject* WorldContext, struct FString* MainMod, struct FString* SubMod);
	static bool FilterOKForCurrentModeString(const struct FString& CurrentModeString, const struct FString& CurrentExtraModeString, const struct FString& ModStringInfo, unsigned char ModeType, int ModeOpenFlag);
	static void ClearPassiveDownloadResourcePaths();
	static void ClearPassiveDownloadResourceIDList();
	static void AddPassiveResourceDownloadFlag(int ItemId);
};


// Class Basic.VisionOptimizationDataProviderInterface
// 0x0000 (0x0028 - 0x0028)
class UVisionOptimizationDataProviderInterface : public UInterface
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class Basic.VisionOptimizationDataProviderInterface");
		return pStaticClass;
	}

};


}

