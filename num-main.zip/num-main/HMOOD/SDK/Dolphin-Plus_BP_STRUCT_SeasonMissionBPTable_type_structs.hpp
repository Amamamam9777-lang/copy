#pragma once

// WE SUPPORT FUN  (4.7.0) SDKGen by @Dolphin-Plus | @T4_Q3 
// Send Message Me For SDKGen Tool  
// Generate on Thu Nov 12 21:01:43 2026
 
namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_SeasonMissionBPTable_type.BP_STRUCT_SeasonMissionBPTable_type
// 0x0038
struct FBP_STRUCT_SeasonMissionBPTable_type
{
	struct FString                                     CName_0_3B02C7C021A8868F32F1BA220D295515;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_73B51A0066811C521281291A0132D224;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Path_2_746EFA0071EA42DC1C74470F02D39998;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Wrapper_3_324A4F00599DC022161C6E8C019B5BF2;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

